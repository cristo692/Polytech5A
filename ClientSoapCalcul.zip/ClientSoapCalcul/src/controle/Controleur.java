package controle;

import java.io.IOException;
import java.rmi.RemoteException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.axis2.AxisFault;

import fr.polytech.clacul.CalculetteStub;
import fr.polytech.clacul.CalculetteStub.GetAddition;
import fr.polytech.clacul.CalculetteStub.GetDivision;
import fr.polytech.clacul.CalculetteStub.GetMultiplication;
import fr.polytech.clacul.CalculetteStub.GetSoustraction;

import fr.polytech.clacul.CalculetteStub.GetAdditionResponse;
import fr.polytech.clacul.CalculetteStub.GetDivisionResponse;
import fr.polytech.clacul.CalculetteStub.GetMultiplicationResponse;
import fr.polytech.clacul.CalculetteStub.GetSoustractionResponse;


/**
 * Servlet implementation class Controleur
 */
public class Controleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controleur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			appelWebservice(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void appelWebservice(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String nbrea = request.getParameter("nombrea");
		String nbreb = request.getParameter("nombreb");
		String operation = request.getParameter("operation");
		float r=0;
		float a = Float.parseFloat(nbrea);
		float b = Float.parseFloat(nbreb);

		CalculetteStub service = new CalculetteStub();

		try {
			// Mise en oeuvre du service par application directe des m�thodes

			if (operation.equals("addition")) {
				GetAddition ad = new GetAddition();
				GetAdditionResponse sr = new GetAdditionResponse();
				ad.setOpera(a);
				ad.setOperb(b);
				sr = service.getAddition(ad);
				 r = sr.get_return();
			} else if (operation.equals("soustraction")) {
				GetSoustraction ad = new GetSoustraction();
				GetSoustractionResponse sr = new GetSoustractionResponse();
				ad.setOpera(a);
				ad.setOperb(b);
				sr = service.getSoustraction(ad);
				r = sr.get_return();

			} else if (operation.equals("multiplication")) {
				GetMultiplication ad = new GetMultiplication();
				GetMultiplicationResponse sr = new GetMultiplicationResponse();
				ad.setOpera(a);
				ad.setOperb(b);
				sr = service.getMultiplication(ad);
				 r = sr.get_return();
			} else {
				GetDivision dd = new GetDivision();
				GetDivisionResponse sr = new GetDivisionResponse();
				dd.setOpera(a);
				dd.setOperb(b);
				if (b != 0) {
					sr = service.getDivision(dd);
					r= sr.get_return();
				}
			}
			request.setAttribute("operandeA", String.valueOf(a));
			request.setAttribute("operandeB", String.valueOf(b));
			request.setAttribute("operation", operation);
			request.setAttribute("resultat", String.valueOf(r));

			this.getServletContext()
					.getRequestDispatcher("/ResultatOperation.jsp")
					.forward(request, response);

		} catch (AxisFault t) {
			t.printStackTrace();
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}

	}

}
