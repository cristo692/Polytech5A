/**
 * ServiceMonExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.8  Built on : May 19, 2018 (07:06:11 BST)
 */
package client;

public class ServiceMonExceptionException extends java.lang.Exception {
    private static final long serialVersionUID = 1568279352373L;
    private client.ServiceStub.ServiceMonException faultMessage;

    public ServiceMonExceptionException() {
        super("ServiceMonExceptionException");
    }

    public ServiceMonExceptionException(java.lang.String s) {
        super(s);
    }

    public ServiceMonExceptionException(java.lang.String s,
        java.lang.Throwable ex) {
        super(s, ex);
    }

    public ServiceMonExceptionException(java.lang.Throwable cause) {
        super(cause);
    }

    public void setFaultMessage(client.ServiceStub.ServiceMonException msg) {
        faultMessage = msg;
    }

    public client.ServiceStub.ServiceMonException getFaultMessage() {
        return faultMessage;
    }
}
