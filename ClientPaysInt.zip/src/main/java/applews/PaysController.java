package applews;

import client.ServiceMonExceptionException;
import client.ServiceStub;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * Servlet implementation class PaysController
 */
@WebServlet("/pays")
public class PaysController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaysController() {
        super();
        // TODO Auto-generated constructor stub

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			appelWebService(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (ServiceMonExceptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	public void appelWebService(HttpServletRequest request,
	HttpServletResponse response) throws ServletException, IOException, ServiceMonExceptionException {

		ServiceStub service = new ServiceStub();
				
		ServiceStub.ConsulterListePays mesPays = new ServiceStub.ConsulterListePays();

		ServiceStub.ConsulterListePaysResponse sr; 

		List<ServiceStub.Pays> listePays = new ArrayList<ServiceStub.Pays>();

		//service = new PaysServiceStub();
		//PaysServiceStub.ConsulterListePays consulterListePays= new PaysServiceStub.ConsulterListePays();
		//PaysServiceStub.ConsulterListePaysResponse consulterListePaysResponse ;
		//consulterListePaysResponse = service.consulterListePays(consulterListePays);
		//PaysServiceStub.Pays[] tabPays = consulterListePaysResponse.get_return();
		//List<PaysServiceStub.Pays> listPays = new ArrayList<>(Arrays.asList(tabPays));
		//request.setAttribute("listePays", listPays);




       try 
       {
			sr = service.consulterListePays(mesPays);
		   ServiceStub.Pays[]  tabPays = sr.get_return();
			for ( int i=0; i < tabPays.length;i++)
			   {
				listePays.add(tabPays[i]);
			   }
			
       } catch (ServiceMonExceptionException e) {
           e.printStackTrace();
       }

			
			request.setAttribute("liste", listePays);
			
			this.getServletContext().getRequestDispatcher("/pays.jsp").forward(request, response);

	}
}
	
	


