package models;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigInteger;
import java.util.Objects;


/**
 * The persistent class for the pays database table.
 * 
 */
@Entity
@Table(name="pays")
public class Pays implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NOM_PAYS")
	private String nomPays;

	@Column(name="NB_HABITANTS")
	private long nbHabitants;
	@Column(name="NOM_CAPITALE")
	private String nomCapitale;
	@Column(name="NOM_CONTINENT")
	private String nomContinent;

	public Pays() {
	}

	@Id
	@Column(name = "NOM_PAYS", nullable = false, length = 100)
	public String getNomPays() {
		return this.nomPays;
	}

	public void setNomPays(String nomPays) {
		this.nomPays = nomPays;
	}

	@Basic
	@Column(name = "NB_HABITANTS", nullable = false)
	public long getNbHabitants() {
		return this.nbHabitants;
	}

	public void setNbHabitants(Long nbHabitants) {
		this.nbHabitants = nbHabitants;
	}

	public void setNbHabitants(long nbHabitants) {
		this.nbHabitants = nbHabitants;
	}

	@Basic
	@Column(name = "NOM_CAPITALE", nullable = false, length = 100)
	public String getNomCapitale() {
		return this.nomCapitale;
	}

	public void setNomCapitale(String nomCapitale) {
		this.nomCapitale = nomCapitale;
	}

	@Basic
	@Column(name = "NOM_CONTINENT", nullable = false, length = 100)
	public String getNomContinent() {
		return this.nomContinent;
	}

	public void setNomContinent(String nomContinent) {
		this.nomContinent = nomContinent;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Pays pays = (Pays) o;
		return Objects.equals(nomPays, pays.nomPays) &&
				Objects.equals(nbHabitants, pays.nbHabitants) &&
				Objects.equals(nomCapitale, pays.nomCapitale) &&
				Objects.equals(nomContinent, pays.nomContinent);
	}

	@Override
	public int hashCode() {
		return Objects.hash(nomPays, nomCapitale, nomContinent, nbHabitants);
	}
}